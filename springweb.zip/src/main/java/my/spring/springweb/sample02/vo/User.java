package my.spring.springweb.sample02.vo;

import lombok.Data;

@Data
public class User {
	
	private String userName;
	private int userAge;
	private String userDept;
	private String userAddress;
	
}